
public class Player {
	public String name;
	public int chips = 0;
	
	public Player(String name)
	{
		this.name = name;
	}
	
	public void addChips(int chips)
	{
		this.chips += chips;
	}
	
	public int getChips()
	{
		return chips;
	}
}
