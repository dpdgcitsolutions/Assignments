import java.util.*;


public class GamePlay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String option = "";
		Scanner kbd = new Scanner(System.in);
		int totalChips = 0, turn = 0, chipsTaken = 0, winner = 0;
		do
		{
			// create players
			ArrayList<Player> players = new ArrayList<Player>();
			System.out.print("What is the name of the first player? ");
			String name = kbd.next();
			Player player1 = new Player(name);
			System.out.print("What is the name of the first player? ");
			name = kbd.next();
			while( name.toLowerCase().equals(player1.name.toLowerCase()) )
			{
				System.out.print("Both players cannot be named " + name + ". Enter a different name: ");
				name = kbd.next();
			}
			Player player2 = new Player(name);
			players.add(player1);
			players.add(player2);
			
			// get number of chips
			System.out.print("How many chips does the initial pile contain? ");
			totalChips = kbd.nextInt();
			while( totalChips < 3 || totalChips%2 == 0 )
			{
				if( totalChips < 3 )
				{
					System.out.print("You have to start with at least 3 chips. Choose another number: ");
					totalChips = kbd.nextInt();
				}
				else if( totalChips%2 == 0 )
				{
					System.out.print("You have to start with an odd number of chips. Choose another number: ");
					totalChips = kbd.nextInt();
				}
			}
			
			// game play
			do
			{
				System.out.printf("\n* * * * * * * * * * * * * * * * * * * * * * * * * * *\n\n");
				System.out.println(players.get(turn).name + " has " + players.get(turn).chips + " chips.");
				System.out.println(players.get((turn+1)%2).name + " has " + players.get((turn+1)%2).chips + " chips.");
				System.out.println("It's your turn, " + players.get(turn).name + ".");
				System.out.println("There are " + totalChips + " chips remaining.");
				if( totalChips > 1 )
				{
					System.out.print("You may take any number of chips from 1 to " + totalChips/2 + ". How many will you take, " + players.get(turn).name + "? ");
					chipsTaken = kbd.nextInt();
					while( chipsTaken == 0 || chipsTaken > totalChips/2 )
					{
						if( chipsTaken == 0 )
						{
							System.out.println("Illegal move: you must take at least one chip.");
							System.out.print("How many will you take, " + players.get(turn).name + "? ");
							chipsTaken = kbd.nextInt();
						}
						else if( chipsTaken > totalChips/2 )
						{
							System.out.print("Illegal move: you may not take more than " + totalChips/2 + " chips. ");
							System.out.print("How many will you take, " + players.get(turn).name + "? ");
							chipsTaken = kbd.nextInt();
						}
					}
				}
				else
				{
					System.out.print("How many will you take, " + players.get(turn).name + "? ");
					chipsTaken = kbd.nextInt();
					if( chipsTaken > 1 )
						System.out.print("You can only take one chip.");
					chipsTaken = 1;
				}
				players.get(turn).addChips(chipsTaken);
				totalChips -= chipsTaken;
				turn = (turn+1)%2; // switch turn
			} while( totalChips > 0 );
			
			// result
			turn = 0;
			System.out.printf("\n" + players.get(turn).name + " has " + players.get(turn).chips + " chips.\n");
			System.out.printf(players.get(turn+1).name + " has " + players.get(turn+1).chips + " chips.\n");
			if( players.get(turn).chips % 2 == 0 )
				winner = turn;
			else
				winner = turn + 1;
			System.out.printf(players.get(winner).name + " wins!\n\n");
			System.out.print("Play another game? (y/n) ");
			option = kbd.next();
			System.out.println();
			
		} while( option.toLowerCase().equals("y") );
	}

}