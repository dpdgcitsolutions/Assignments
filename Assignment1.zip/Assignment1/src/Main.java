import java.util.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int number = r.nextInt(101);
		Scanner kbd = new Scanner(System.in);
		System.out.println("Guess a number between 0 to 100");
		int guess = -1, chances = 0, condition = 0;

		while( condition == 0 )
		{
			try
			{
				guess = kbd.nextInt();
				chances++;
				if ( (guess <= number-10 || guess >= number+10) && chances <=5 )
					System.out.println("Wrong number, guess again");
				else
					condition = 1;
					
			}
			catch( Exception e )
			{
				System.out.println("Not a number!");
				return;
			}
		}
		
		if( chances > 5 )
			System.out.println("Sorry. The number is: " + number);
		else
			System.out.println("You found it! The number is: " + number);
	}
}
