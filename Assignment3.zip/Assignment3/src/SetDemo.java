import java.util.*;
import java.io.*;

public class SetDemo {

	public static void main(String[] args) {
		//////////////
		/// Task 1 ///
		//////////////
		task1();
		
		//////////////
		/// Task 2 ///
		//////////////
		task2();
		
		//////////////
		/// Task 3 ///
		//////////////
		task3();
		
	}
	
	public static void task1()
	{
		Set mySet = new HashSet();
		String fruit1 = "pear", fruit2 = "banana", fruit3 = "tangerine", fruit4 = "strawberry", fruit5 = "blackberry";
		mySet.add(fruit1);
		mySet.add(fruit2);
		mySet.add(fruit3);
		mySet.add(fruit4);
		mySet.add(fruit5);

		System.out.print("mySet now contains: ");
		System.out.println(mySet);
		// cardinality
		System.out.println("mySet has: " + mySet.size() + " elements");
		// remove blackberry and strawberry
		mySet.remove(fruit4);
		mySet.remove(fruit5);
		System.out.print("mySet now contains: ");
		System.out.println(mySet);
		// remove all other fruits
		mySet.removeAll(mySet);
		System.out.print("mySet now contains: ");
		System.out.println(mySet);
		// show that set is now empty
		System.out.println("mySet is empty: " + mySet.isEmpty());
		System.out.printf("\n***********************************\n\n");
	}
	
	public static void task2()
	{
		// construct a list
		ArrayList<String> myList = new ArrayList<String>();
		String fruit1 = "pear", fruit2 = "banana", fruit3 = "tangerine", fruit4 = "strawberry", fruit5 = "blackberry";
		myList.add(fruit1);
		myList.add(fruit2);
		myList.add(fruit3);
		myList.add(fruit4);
		myList.add(fruit5);
		// display
		System.out.println("myList's contents in order of insertion: ");
		Iterator itr = myList.iterator();
		while( itr.hasNext() )
			System.out.print( itr.next() + " " );
		System.out.println();
		System.out.println("myList's contents in reverse order: ");
		ListIterator litr = myList.listIterator(myList.size());
		while( litr.hasPrevious() )
			System.out.print( litr.previous() + " " );
		System.out.println();
		// add a second banana
		myList.add(3, "banana");
		System.out.print("myList now contains: ");
		System.out.println(myList);
		System.out.printf("\n***********************************\n\n");
	}
	
	public static void task3()
	{
		String line = "";
		Double average = 0.0, std = 0.0;
		Map<String, Double> grade = new HashMap<String, Double>();
		Map<String, Integer> frequency = new TreeMap<String, Integer>();
		File file = new File("gradeFile.txt");
		File outputFile = new File("output.txt");
		try
		{
	         BufferedReader br = new BufferedReader(new FileReader(file));
	         BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
	         while ((line = br.readLine()) != null)
	         {
	        	 String[] words = line.split(" ");
	        	 if( grade.containsKey(words[0]) )
	        	 {
	        		 double newGrade = (double) grade.get(words[0])+ Double.parseDouble(words[1]);
	        		 grade.replace(words[0], newGrade);
	        		 int newFrequency = (int) frequency.get(words[0]) + 1;
	        		 frequency.replace(words[0], newFrequency);
	        	 }
	        	 else
	        	 {
	        		 grade.put(words[0], Double.parseDouble(words[1]));
	        		 frequency.put(words[0], 1);
	        	 }
	         }
	         
	         Map<String, Double> treeGrade = new TreeMap<String, Double>(grade);
	         writer.write(String.format("Alpha order:\n"));
	         for (Map.Entry<String, Double> entry : treeGrade.entrySet())
	         {
        	    String name = entry.getKey().toString();
        	    int freq = (int) frequency.get(name);
        	    Double mark = entry.getValue()/freq;
        	    grade.replace(name, mark);
        	    treeGrade.replace(name, mark);
        	    writer.write(String.format(name + " " + freq + " " + mark +"\n"));
	         }
	         
	         writer.write("\nMerit order:\n");
	         ArrayList<String> mapKeys = new ArrayList<String>(grade.keySet());
	         ArrayList<Double> mapValues = new ArrayList<Double>(grade.values());
	         
	         for( int i = 0; i < mapKeys.size(); i++ )
	        	 for( int j = 0; j < mapKeys.size()-1; j++ )
	        	 {
	        		 if( mapValues.get(j) < mapValues.get(j+1) )
	        		 {
	        			 Collections.swap(mapValues, j, j+1);
	        			 Collections.swap(mapKeys, j, j+1);
	        		 }
	        	 }
	         int rank = 0;
	         double currentGrade = 0;
	         for( int i = 0; i < mapKeys.size(); i++ )
	         {
	        	 if( currentGrade != mapValues.get(i) )
	        		 rank++;
	        	 writer.write(String.format(rank + " " + mapKeys.get(i) + " " + frequency.get(mapKeys.get(i)) + " " + mapValues.get(i) +"\n"));
	        	 average += mapValues.get(i);
	         }
	         System.out.println();
	         
	         average /= mapKeys.size();
	         writer.write(String.format("\nNumber of students: " + mapKeys.size() + "\n"));
	         writer.write(String.format("Average student mark: %.1f\n", average));
	         
	         // standard deviation
	         for( int i = 0; i < mapKeys.size(); i++ )
	        	 std += Math.pow(mapValues.get(i) - average, 2);
	         std /= mapKeys.size()-1;
	         std = Math.sqrt(std);
	         writer.write(String.format("Standard deviation: %.1f\n", std));
	         writer.close();
		}
		catch(Exception e)
		{
	         e.printStackTrace();
		}
		
		
	}
}
